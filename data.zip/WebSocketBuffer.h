#ifndef VUSER_WEBSOCKET_BUFFER_HEADER
#define VUSER_WEBSOCKET_BUFFER_HEADER

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

char WebSocketReceive0[] = "var myEnv = lsc;\n"
                        "var phase = null;\n"
                        "function setPhase(ph) {\n"
                        " phase = ph;\n"
                        "}\n"
                        "\n"
                        "var winPhase = {};\n"
                        "function setWin(tbl, ph) {\n"
                        " winPhase[tbl] = ph;\n"
                        "}\n"
                        "\n"
                        "var clsd = false;\n"
                        "function c(cod, ph, tbl, its, flds, key, com) {\n"
                        " LS_window.LS_w(cod, ph, tbl, its, flds, key, com);\n"
                        "}\n"
                        "\n"
                        "function error(cod, ph, tbl, msg) {\n"
                        " if (tbl != null) {\n"
                        "  LS_window.LS_l(cod, ph, tbl, msg);\n"
                        " } else {\n"
                        "  LS_window.LS_l(cod, phase, null, msg);\n"
                        " }\n"
                        "}\n"
                        "\n"
                        "function start(sID, addr, kaMs, reqLim, srv, ip) {\n"
                        " LS_window.LS_e(1, phase, sID, addr, kaMs, reqLim, srv, ip);\n"
                        "}\n"
                        "\n"
                        "function end(cause) {\n"
                        " LS_window.LS_e(4, phase, cause);\n"
                        "}\n"
                        "\n"
                        "function loop(holdMs) {\n"
                        " LS_window.LS_e(2, phase, holdMs);\n"
                        "}\n"
                        "\n"
                        "function retry() {\n"
                        " LS_window.LS_e(3, phase);\n"
                        "}\n"
                        "\n"
                        "function bw(maxBW) {\n"
                        " LS_window.LS_e(5, phase, maxBW);\n"
                        "}\n"
                        "\n"
                        "function y(secs) {\n"
                        " LS_window.LS_s(phase, secs);\n"
                        "}\n"
                        "\n"
                        "var unchangedSignal = {};\n"
                        "unchangedSignal.length = -1;\n"
                        "function convert(b, f) {\n"
                        "  var a, c, d = f, e = [];\n"
                        "  for(a = 0;a < b.length;a++) {\n"
                        "    if(a < f) {\n"
                        "      e[a] = b[a]\n"
                        "    } else {\n"
                        "      if(b[a].charAt) {\n"
                        "        b[a] == '$' ? e[d] = '' : b[a] == '#' ? e[d] = null : (c = b[a].charAt(0"
                        "), e[d] = c == '$' || c == '#' ? b[a].substring(1) : b[a]), d++\n"
                        "      } else {\n"
                        "        for(c = 0;c < b[a];c++) {\n"
                        "          e[d] = unchangedSignal, d++\n"
                        "        }\n"
                        "      }\n"
                        "    }\n"
                        "  }\n"
                        "  return e;\n"
                        "}\n"
                        "function d(tbl) {\n"
                        " try { LS_window.LS_u(winPhase[tbl], convert(d.arguments || arguments, 2)); } ca"
                        "tch(exc) {}\n"
                        "}\n"
                        "function z(tbl) {\n"
                        " LS_window.LS_v(winPhase[tbl], convert(z.arguments || arguments, 2));\n"
                        "}\n"
                        "function n(tbl) {\n"
                        " LS_window.LS_n(winPhase[tbl], n.arguments || arguments);\n"
                        "}\n"
                        "function s(tbl) {\n"
                        " LS_window.LS_s(winPhase[tbl], s.arguments || arguments);\n"
                        "}\n"
                        "function r(tbl) {\n"
                        " LS_window.LS_o(winPhase[tbl], r.arguments || arguments);\n"
                        "}\n"
                        "function p() {\n"
                        " LS_window.LS_u(phase, p.arguments || arguments);\n"
                        "}\n"
                        "myEnv.setPhase = setPhase;\n"
                        "myEnv.setWin = setWin;\n"
                        "myEnv.c = c;\n"
                        "myEnv.error = error;\n"
                        "myEnv.end = end;\n"
                        "myEnv.start = start;\n"
                        "myEnv.loop = loop;\n"
                        "myEnv.retry = retry;\n"
                        "myEnv.bw = bw;\n"
                        "myEnv.y = y;\n"
                        "myEnv.convert = convert;\n"
                        "myEnv.d = d;\n"
                        "myEnv.z = z;\n"
                        "myEnv.n = n;\n"
                        "myEnv.s = s;\n"
                        "myEnv.r = r;\n"
                        "myEnv.p = p;\n"
                        "myEnv.LS_window = LS_window;\n"
                        "\n"
                        "// END OF HEADER\n"
                        "\n"
                        "setPhase(9903);\n"
                        "start('S4cfaf04427653e8T5219426', null, 5000, 50000);\n";
long WebSocketReceiveLen0   = sizeof(WebSocketReceive0) - 1;	// (record-time: 2208 bytes)

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

char WebSocketReceive1[] = "bw(0.0);\n";
long WebSocketReceiveLen1   = sizeof(WebSocketReceive1) - 1;	// (record-time: 9 bytes)

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

char WebSocketReceive2[] = "c(6,1,1,10,12,-1,-1);setWin(1,1);z(1,1,'Anduct','2.65','09:52:03','-12.82','5450"
                        "0','2.65','2.66','55000','2.53','3.52','3.04','3.1');z(1,2,'Ations Europe','17.3"
                        "8','09:52:20','8.01','27000','17.38','17.4','12500','12.71','19.57','16.09','16."
                        "2');z(1,3,'Bagies Consulting','7.38','09:52:17','2.64','9500','7.38','7.39','280"
                        "00','5.8','8.64','7.19','7.25');z(1,4,'BAY Corporation','3.56','09:52:11','-1.92"
                        "','5000','3.55','3.56','62500','3.28','4.12','3.63','3.62');z(1,7,'CVS Asia','17"
                        ".22','09:52:20','11.89','43500','17.17','17.22','49000','12.56','18.47','15.39',"
                        "'15.85');z(1,8,'Datio PLC','5.22','09:52:15','-1.69','2000','5.22','5.24','73000"
                        "','4.37','6.3','5.31','5.31');z(1,5,'CON Consulting','8.1','09:52:20','6.43','42"
                        "000','8.09','8.1','2000','6.08','9.11','7.61','7.65');z(1,6,'Corcor PLC','2.32',"
                        "'09:52:20','0.86','93500','2.32','2.33','33000','1.86','2.73','2.3','2.3');z(1,9"
                        ",'Dentems','4.92','09:52:20','1.23','33000','4.91','4.92','12500','4.01','5.79',"
                        "'4.86','4.97');z(1,10,'ELE Manufacturing','8.15','09:52:20','7.09','92000','8.14"
                        "','8.15','84500','6.25','8.94','7.61','7.7');\n";
long WebSocketReceiveLen2   = sizeof(WebSocketReceive2) - 1;	// (record-time: 1086 bytes)

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

char WebSocketReceive3[] = "d(1,3,1,'7.37','09:52:20','2.5','79500','7.37',1,'23000',4);\n";
long WebSocketReceiveLen3   = sizeof(WebSocketReceive3) - 1;	// (record-time: 61 bytes)

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

char WebSocketReceive4[] = "d(1,2,2,'09:52:21',1,'56500','17.35','17.38','14500',4);\n";
long WebSocketReceiveLen4   = sizeof(WebSocketReceive4) - 1;	// (record-time: 57 bytes)

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

char WebSocketReceive5[] = "d(1,8,1,'5.25','09:52:21','-1.12','74500','5.24','5.25','64500',4);\n";
long WebSocketReceiveLen5   = sizeof(WebSocketReceive5) - 1;	// (record-time: 68 bytes)

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

char WebSocketReceive6[] = "d(1,2,1,'17.39',1,'8.07','25500','17.33','17.39','50500',4);\n";
long WebSocketReceiveLen6   = sizeof(WebSocketReceive6) - 1;	// (record-time: 61 bytes)

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

char WebSocketReceive7[] = "d(1,2,1,'17.25','09:52:22','7.2','43000','17.25','17.3','87500',4);\n";
long WebSocketReceiveLen7   = sizeof(WebSocketReceive7) - 1;	// (record-time: 68 bytes)

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

char WebSocketReceive8[] = "d(1,7,1,'17.18','09:52:22','11.63','49500','17.16','17.18','5000',4);\n";
long WebSocketReceiveLen8   = sizeof(WebSocketReceive8) - 1;	// (record-time: 70 bytes)

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

char WebSocketReceive9[] = "d(1,2,1,'17.23',1,'7.08','20000','17.23','17.25','40500',4);\n";
long WebSocketReceiveLen9   = sizeof(WebSocketReceive9) - 1;	// (record-time: 61 bytes)

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

char WebSocketReceive10[] = "d(1,9,1,'4.88','09:52:23','0.41',1,'4.88','4.89','62000',4);\n";
long WebSocketReceiveLen10   = sizeof(WebSocketReceive10) - 1;	// (record-time: 61 bytes)

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

char WebSocketReceive11[] = "d(1,2,1,'17.08','09:52:23','6.15','71000','17.06','17.08','68500',4);\n";
long WebSocketReceiveLen11   = sizeof(WebSocketReceive11) - 1;	// (record-time: 70 bytes)

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

char WebSocketReceive12[] = "d(1,2,1,'16.94','09:52:24','5.28','57500','16.88','16.94','25500',4);\n";
long WebSocketReceiveLen12   = sizeof(WebSocketReceive12) - 1;	// (record-time: 70 bytes)

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

char WebSocketReceive13[] = "d(1,7,1,'17.19','09:52:24','11.69','75000','17.14','17.19','8500',4);\n";
long WebSocketReceiveLen13   = sizeof(WebSocketReceive13) - 1;	// (record-time: 70 bytes)

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

char WebSocketReceive14[] = "d(1,3,1,'7.36','09:52:24','2.36','54500','7.35','7.36','9500',4);\n";
long WebSocketReceiveLen14   = sizeof(WebSocketReceive14) - 1;	// (record-time: 66 bytes)

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

char WebSocketReceive15[] = "d(1,5,2,'09:52:24',1,'21500','8.1','8.11','76500',4);\n";
long WebSocketReceiveLen15   = sizeof(WebSocketReceive15) - 1;	// (record-time: 54 bytes)

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

char WebSocketReceive16[] = "d(1,2,1,'16.99',1,'5.59','31500','16.99','17.01','66500',4);\n";
long WebSocketReceiveLen16   = sizeof(WebSocketReceive16) - 1;	// (record-time: 61 bytes)

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

char WebSocketReceive17[] = "y(5);\n"
                        "d(1,2,1,'17.1','09:52:25','6.27','99500','17.04','17.1','7000',4);\n";
long WebSocketReceiveLen17   = sizeof(WebSocketReceive17) - 1;	// (record-time: 73 bytes)

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

char WebSocketReceive18[] = "d(1,2,1,'17.08','09:52:26','6.15',1,'17.08',1,'50000',4);\n";
long WebSocketReceiveLen18   = sizeof(WebSocketReceive18) - 1;	// (record-time: 58 bytes)

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

char WebSocketReceive19[] = "d(1,7,1,'17.3','09:52:26','12.41','73000','17.3','17.35','3500',4);\n";
long WebSocketReceiveLen19   = sizeof(WebSocketReceive19) - 1;	// (record-time: 68 bytes)

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

char WebSocketReceive20[] = "d(1,2,1,'17.17',1,'6.71','11000','17.17','17.18','91000',4);\n";
long WebSocketReceiveLen20   = sizeof(WebSocketReceive20) - 1;	// (record-time: 61 bytes)

#endif
