Action()
{

	web_set_sockets_option("SSL_VERSION", "2&3");

	web_add_cookie("has_js=1; DOMAIN=saas.hpe.com");

	web_add_cookie("optimizelyEndUserId=oeu1462501853441r0.2353571691415417; DOMAIN=saas.hpe.com");

	web_add_cookie("optimizelySegments=%7B%22341080973%22%3A%22direct%22%2C%22341080974%22%3A%22false%22%2C%22341372637%22%3A%22ie%22%2C%22341514348%22%3A%22none%22%7D; DOMAIN=saas.hpe.com");

	web_add_cookie("optimizelyBuckets=%7B%7D; DOMAIN=saas.hpe.com");

	web_add_cookie("optimizelyPendingLogEvents=%5B%22n%3Dhttps%253A%252F%252Fsaas.hpe.com%252Fen-us%252Fhome%26u%3Doeu1462501853441r0.2353571691415417%26wxhr%3Dtrue%26time%3D1462501853.483%26f%3D1740740927%2C2002671073%2C3188550359%2C3331680068%2C3380910858%2C3398280273%2C5542580650%2C5536750817%2C5535603073%2C5540680206%2C4470555505%2C5533631379%2C5545570359%26g%3D%22%5D; DOMAIN=saas.hpe.com");

	web_add_cookie("end_user_id=oeu1462501853441r0.2353571691415417; DOMAIN=341015862.log.optimizely.com");

	web_url("home", 
		"URL=https://saas.hpe.com/en-us/home", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=../sites/all/themes/zen_pronq_mktg/shared-assets/fonts/opensans-semibold-webfont.eot", ENDITEM, 
		"Url=../sites/all/themes/zen_pronq_mktg/shared-assets/fonts/opensans-bold-webfont.eot", ENDITEM, 
		"Url=../sites/all/themes/zen_pronq_mktg/shared-assets/fonts/opensans-light-webfont.eot", ENDITEM, 
		"Url=../sites/all/themes/zen_pronq_mktg/shared-assets/fonts/Metric.eot", ENDITEM, 
		"Url=../sites/all/themes/zen_pronq_mktg/shared-assets/fonts/opensans-regular-webfont.eot", ENDITEM, 
		"Url=../sites/all/themes/zen_pronq_mktg/shared-assets/fonts/fontawesome-webfont.eot", ENDITEM, 
		"Url=../sites/all/themes/zen_pronq_mktg/shared-assets/img/hpelogo.svg", ENDITEM, 
		"Url=../sites/all/themes/zen_pronq_mktg/shared-assets/img/hpelogo-black.svg", ENDITEM, 
		"Url=https://doug1izaerwt3.cloudfront.net/7f84591bfa1649cd3fe73153dab5ce79e2bd79f8.1.js", ENDITEM, 
		"Url=https://cdn3.optimizely.com/js/geo2.js", ENDITEM, 
		"Url=https://www.googletagmanager.com/gtm.js?id=GTM-KPNTJD", ENDITEM, 
		"Url=https://i.kissmetrics.com/i.js", ENDITEM, 
		"Url=https://trk.kissmetrics.com/e?URL=https%3A%2F%2Fsaas.hpe.com%2Fen-us%2Fhome&Referrer=Direct&KM%20Screen%20Resolution=1920x1080&_n=Visited%20Site&_k=7f84591bfa1649cd3fe73153dab5ce79e2bd79f8&_p=qwbs%2FcdzbMyJ0UrBBHZdkKnuwGM%3D&_t=1462501884", ENDITEM, 
		"Url=https://341015862.log.optimizely.com/event?a=341015862&d=223126303&y=false&src=js&s341080973=direct&s341080974=false&s341372637=ie&s341514348=none&tsent=1462501853.485&n=https%3A%2F%2Fsaas.hpe.com%2Fen-us%2Fhome&u=oeu1462501853441r0.2353571691415417&wxhr=true&time=1462501853.483&f=1740740927,2002671073,3188550359,3331680068,3380910858,3398280273,5542580650,5536750817,5535603073,5540680206,4470555505,5533631379,5545570359&g=&cx2=4f1993dd", ENDITEM, 
		"Url=https://341015862.log.optimizely.com/event?a=341015862&d=223126303&y=false&src=js&s341080973=direct&s341080974=false&s341372637=ie&s341514348=none&tsent=1462501894.846&n=engagement&u=oeu1462501853441r0.2353571691415417&wxhr=true&time=1462501894.846&f=1740740927,2002671073,3188550359,3331680068,3380910858,3398280273,5542580650,5536750817,5535603073,5540680206,4470555505,5533631379,5545570359&g=340963885&cx2=e22cd55", ENDITEM, 
		"Url=https://www.google-analytics.com/analytics.js", ENDITEM, 
		LAST);

	web_url("fontawesome-webfont.eot", 
		"URL=https://saas.hpe.com/sites/all/themes/zen_pronq_mktg/shared-assets/cms/fonts/fontawesome-webfont.eot?", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://saas.hpe.com/en-us/home", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		LAST);

	web_url("fontawesome-webfont.woff", 
		"URL=https://saas.hpe.com/sites/all/themes/zen_pronq_mktg/shared-assets/cms/fonts/fontawesome-webfont.woff?v=4.0.3", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://saas.hpe.com/en-us/home", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		LAST);

	web_url("fontawesome-webfont.ttf", 
		"URL=https://saas.hpe.com/sites/all/themes/zen_pronq_mktg/shared-assets/cms/fonts/fontawesome-webfont.ttf?v=4.0.3", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://saas.hpe.com/en-us/home", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("optimizelyPendingLogEvents=%5B%5D; DOMAIN=saas.hpe.com");

	web_add_cookie("kvcd=1462501884472; DOMAIN=saas.hpe.com");

	web_add_cookie("km_ai=qwbs%2FcdzbMyJ0UrBBHZdkKnuwGM%3D; DOMAIN=saas.hpe.com");

	web_add_cookie("km_uq=1462501885%20%2Fs%3FBrowser%2520Version%3D7.0%26_k%3D7f84591bfa1649cd3fe73153dab5ce79e2bd79f8%26_p%3Dqwbs%252FcdzbMyJ0UrBBHZdkKnuwGM%253D%26_t%3D1462501885%7C1462501885%20%2Fs%3FScreen%2520Resolution%3D1920%2520x%25201080%26_k%3D7f84591bfa1649cd3fe73153dab5ce79e2bd79f8%26_p%3Dqwbs%252FcdzbMyJ0UrBBHZdkKnuwGM%253D%26_t%3D1462501885%7C1462501885%20%2Fs%3FLanguage%3Den-GB%26_k%3D7f84591bfa1649cd3fe73153dab5ce79e2bd79f8%26_p%3Dqwbs%252FcdzbMyJ0UrBBHZdkKnuwGM%253D%26_t%3D1462501885; "
		"DOMAIN=saas.hpe.com");

	web_add_cookie("km_vs=1; DOMAIN=saas.hpe.com");

	web_add_cookie("km_lv=1462501885; DOMAIN=saas.hpe.com");

	web_link("Home", 
		"Text=Home", 
		"Ordinal=1", 
		"Snapshot=t5.inf", 
		LAST);

	return 0;
}