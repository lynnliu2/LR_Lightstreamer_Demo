#ifndef _GLOBALS_H 
#define _GLOBALS_H

#include "MqttApi.h"

/* client session handle */
MQTT client;

#endif // _GLOBALS_H  
