﻿Action()
{
mqtt_publish(client, "MQTT1", "Hello world!", MQTT_AUTO, 2, MQTT_RETAIN);

 

return 0;
	
}
